package com.omega.ircam

import java.io.DataOutputStream
import java.io.File
import java.io.FileOutputStream

object IrIlluminatorHelper {
    private val IR_LED_PATHS = listOf(
        "/sys/class/leds/led:torch_2/brightness",
        "/sys/devices/soc/soc:qcom,camera-flash/leds/led:torch_2/brightness"
    )
    private var activePath: String? = null

    init {
        activePath = IR_LED_PATHS.firstOrNull { File(it).exists() }
    }

    fun setLedState(enable: Boolean, brightness: Int = 200): Boolean {
        val path = activePath ?: IR_LED_PATHS[0]
        val value = if (enable) brightness.coerceIn(0, 255) else 0

        try {
            val file = File(path)
            if (file.canWrite()) {
                FileOutputStream(file).use { fos ->
                    fos.write(value.toString().toByteArray())
                    fos.flush()
                }
                return true
            }
        } catch (_: Exception) { }

        return try {
            val process = Runtime.getRuntime().exec("su")
            DataOutputStream(process.outputStream).use { os ->
                os.writeBytes("echo $value > $path\n")
                os.writeBytes("exit\n")
                os.flush()
            }
            process.waitFor() == 0
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun turnOn(brightness: Int = 200) = setLedState(true, brightness)
    fun turnOff() = setLedState(false)
}
