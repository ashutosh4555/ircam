# IRCam

A Camera2 app that doesn't trust `cameraIdList`. Built for the Poco F1 (beryllium) IR camera on LineageOS, but works on any Android 10+ phone.

## Build

Open the folder in Android Studio and press Run, or from a terminal:

    gradle wrapper --gradle-version 8.7
    ./gradlew assembleDebug
    adb install -r app/build/outputs/apk/debug/app-debug.apk

Needs JDK 17 and the Android SDK (platform 34).

## What it does

- **Camera spinner**: lists advertised IDs, plus *hidden* (readable but not advertised) and *blind* IDs 0-11 (not readable, may still open).
- **Probe**: tries to open every ID and reports OPENS / error code / exception. This is the quickest way to learn whether the HAL exposes the IR sensor at all.
- **Info**: dumps characteristics - color filter (NIR shows up here), capabilities, ISO/exposure ranges, every output format and size.
- **Photo**: JPEG, or RAW -> DNG (tick RAW/DNG). Saved to Pictures/IRCam.
- **Rec**: H.264 MP4 with audio, saved to Movies/IRCam.
- **Ctrl**: manual ISO, exposure (log scale), focus distance, torch.
- **Analysis view**: bypasses the normal preview and reads raw frames (YUV luma, Y8 or RAW16) into a grayscale view with Gray / Auto-contrast / False color / Inverted filters. Photo saves the processed frame as PNG. This is the mode to use for IR / mono sensors that only offer YUV or raw output.

## Reading the results

- If an ID shows **OPENS**, the HAL allows it and you can use it here.
- If every extra ID errors out, the sensor isn't exposed by the camera HAL at all. No app can fix that; it needs vendor HAL work.
- The IR **illuminator** is usually a separate LED driven by the face-unlock stack. Even when the sensor works you may only see ambient IR - sunlight, incandescent bulbs, a TV remote LED.
- Video needs a PRIVATE (encoder) output. Many IR sensors don't offer one, so Rec will say so; use Analysis view + Photo instead.

Not tested on a device; written without an Android SDK available to compile against.
