package com.omega.ircam

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.ImageFormat
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.DngCreator
import android.hardware.camera2.TotalCaptureResult
import android.hardware.camera2.params.StreamConfigurationMap
import android.media.Image
import android.media.ImageReader
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.util.Range
import android.util.Size
import android.view.Gravity
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    // ---- views ----
    private lateinit var cm: CameraManager
    private lateinit var texture: TextureView
    private lateinit var gray: ImageView
    private lateinit var status: TextView
    private lateinit var sliders: View
    private lateinit var camSpinner: Spinner
    private lateinit var filterSpinner: Spinner
    private lateinit var btnRec: Button
    private lateinit var swManual: SwitchCompat
    private lateinit var cbYuv: CheckBox
    private lateinit var cbRaw: CheckBox
    private lateinit var cbTorch: CheckBox
    private lateinit var sbIso: SeekBar
    private lateinit var sbExp: SeekBar
    private lateinit var sbFocus: SeekBar
    private lateinit var tvIso: TextView
    private lateinit var tvExp: TextView
    private lateinit var tvFocus: TextView

    // ---- camera state ----
    private var entries = listOf<CameraProbe.Entry>()
    private var bgThread: HandlerThread? = null
    private var bg: Handler? = null
    @Volatile private var IrIlluminatorHelper.turnOff()
        resumed = false
    @Volatile private var opening = false
    @Volatile private var device: CameraDevice? = null
    @Volatile private var session: CameraCaptureSession? = null
    @Volatile private var chars: CameraCharacteristics? = null
    @Volatile private var camId: String? = null
    @Volatile private var pendingSession = false

    private var previewSurface: Surface? = null
    private var previewReader: ImageReader? = null
    private var captureReader: ImageReader? = null
    @Volatile private var recSurface: Surface? = null

    // ---- options ----
    @Volatile private var wantYuv = false
    @Volatile private var wantRaw = false
    @Volatile private var torchOn = false
    @Volatile private var manual = false
    @Volatile private var filterMode = 0
    @Volatile private var yuvPath = false

    // ---- manual control values ----
    private var isoRange: Range<Int>? = null
    private var expRange: Range<Long>? = null
    private var minFocus = 0f
    private var flashOk = false
    private var iso = 100
    private var expNs = 10_000_000L
    private var focusD = 0f

    // ---- recording ----
    @Volatile private var recording = false
    private var recorder: MediaRecorder? = null
    private var recPfd: ParcelFileDescriptor? = null

    // ---- raw capture handshake ----
    private val rawLock = Any()
    private var pendingRaw: Image? = null
    private var pendingResult: TotalCaptureResult? = null

    // ---- analysis rendering ----
    private var bmp: Bitmap? = null
    private var pix = IntArray(0)
    private var luma = IntArray(0)
    private var frameInfo = ""
    private var lastStatusMs = 0L
    private var lastResult: TotalCaptureResult? = null
    private val heat = IntArray(256) { i ->
        Color.HSVToColor(floatArrayOf(240f * (1f - i / 255f), 1f, 1f))
    }

    // =====================================================================
    // lifecycle
    // =====================================================================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        cm = getSystemService(CameraManager::class.java)

        texture = findViewById(R.id.texture)
        gray = findViewById(R.id.gray)
        status = findViewById(R.id.status)
        sliders = findViewById(R.id.sliders)
        camSpinner = findViewById(R.id.camSpinner)
        filterSpinner = findViewById(R.id.filterSpinner)
        btnRec = findViewById(R.id.btnRec)
        swManual = findViewById(R.id.swManual)
        cbYuv = findViewById(R.id.cbYuv)
        cbRaw = findViewById(R.id.cbRaw)
        cbTorch = findViewById(R.id.cbTorch)
        sbIso = findViewById(R.id.sbIso)
        sbExp = findViewById(R.id.sbExp)
        sbFocus = findViewById(R.id.sbFocus)
        tvIso = findViewById(R.id.tvIso)
        tvExp = findViewById(R.id.tvExp)
        tvFocus = findViewById(R.id.tvFocus)

        filterSpinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Gray (as-is)", "Auto-contrast", "False color (heat)", "Inverted")
        )
        filterSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                filterMode = pos
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        texture.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
                if (pendingSession) {
                    pendingSession = false
                    bg?.post { createSession() }
                }
            }

            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}
            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean = true
            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }

        findViewById<Button>(R.id.btnPhoto).setOnClickListener { takePhoto() }
        btnRec.setOnClickListener { if (recording) stopRecording() else startRecording() }
        findViewById<Button>(R.id.btnCtl).setOnClickListener {
            sliders.visibility = if (sliders.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        findViewById<Button>(R.id.btnInfo).setOnClickListener {
            val id = camId ?: entries.getOrNull(camSpinner.selectedItemPosition)?.id
            if (id != null) showText("Camera info", CameraProbe.describe(cm, id))
        }
        findViewById<Button>(R.id.btnProbe).setOnClickListener { probeAll() }

        swManual.setOnCheckedChangeListener { _, checked ->
            manual = checked
            sbIso.isEnabled = checked
            sbExp.isEnabled = checked
            sbFocus.isEnabled = checked && minFocus > 0f
            pushControls()
        }
        cbYuv.setOnCheckedChangeListener { _, c ->
            wantYuv = c
            bg?.post { createSession() }
        }
        cbRaw.setOnCheckedChangeListener { _, c ->
            wantRaw = c
            bg?.post { createSession() }
        }
        cbTorch.setOnCheckedChangeListener { _, c ->
            torchOn = c
            pushControls()
        }

        val seekListener = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                iso = isoFromSeek(sbIso.progress)
                expNs = expFromSeek(sbExp.progress)
                focusD = minFocus * sbFocus.progress / 100f
                updateLabels()
                pushControls()
            }

            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        }
        sbIso.setOnSeekBarChangeListener(seekListener)
        sbExp.setOnSeekBarChangeListener(seekListener)
        sbFocus.setOnSeekBarChangeListener(seekListener)

        camSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (resumed && bg != null) entries.getOrNull(pos)?.let { openCamera(it.id) }
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        if (hasCameraPerm()) {
            initCameraList()
        } else {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO), 1
            )
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (hasCameraPerm()) {
            initCameraList()
            if (resumed) openSelected()
        } else {
            toast("Camera permission is required")
        }
    }

    override fun onResume() {
        super.onResume()
        IrIlluminatorHelper.turnOn(200)
        resumed = true
        bgThread = HandlerThread("cam").also { it.start() }
        bg = Handler(bgThread!!.looper)
        if (entries.isNotEmpty()) openSelected()
    }

    override fun onPause() {
        IrIlluminatorHelper.turnOff()
        resumed = false
        closeCamera()
        bgThread?.quitSafely()
        bgThread = null
        bg = null
        super.onPause()
    }

    private fun hasCameraPerm() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun hasAudioPerm() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun initCameraList() {
        if (entries.isNotEmpty()) return
        entries = CameraProbe.entries(cm)
        camSpinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, entries.map { it.label }
        )
    }

    private fun openSelected() {
        entries.getOrNull(camSpinner.selectedItemPosition)?.let { openCamera(it.id) }
    }

    // =====================================================================
    // open / close
    // =====================================================================

    @SuppressLint("MissingPermission")
    private fun openCamera(id: String) {
        val handler = bg ?: return
        if (id == camId && (device != null || opening)) return
        closeCamera()
        camId = id
        opening = true
        chars = try {
            cm.getCameraCharacteristics(id)
        } catch (ignored: Throwable) {
            null
        }
        setupControlsFromChars()
        try {
            cm.openCamera(id, object : CameraDevice.StateCallback() {
                override fun onOpened(d: CameraDevice) {
                    opening = false
                    device = d
                    createSession()
                }

                override fun onDisconnected(d: CameraDevice) {
                    d.close()
                    if (device === d) device = null
                    opening = false
                }

                override fun onError(d: CameraDevice, error: Int) {
                    d.close()
                    if (device === d) device = null
                    opening = false
                    camId = null
                    toast("Camera $id error $error (HAL refused to open it)")
                }
            }, handler)
        } catch (t: Throwable) {
            opening = false
            camId = null
            toast("Cannot open camera $id: ${t.message}")
        }
    }

    private fun closeCamera() {
        try {
            if (recording) {
                try { recorder?.stop() } catch (ignored: RuntimeException) {}
                recorder?.release()
                recorder = null
                recPfd?.close()
                recPfd = null
                recording = false
                recSurface = null
                runOnUiThread { btnRec.text = "Rec" }
            }
            closeSession()
            device?.close()
        } catch (ignored: Throwable) {
        }
        device = null
        camId = null
        opening = false
    }

    private fun closeSession() {
        try { session?.close() } catch (ignored: Throwable) {}
        session = null
        try { previewReader?.close() } catch (ignored: Throwable) {}
        previewReader = null
        try { captureReader?.close() } catch (ignored: Throwable) {}
        captureReader = null
        try { previewSurface?.release() } catch (ignored: Throwable) {}
        previewSurface = null
        synchronized(rawLock) {
            pendingRaw?.close()
            pendingRaw = null
            pendingResult = null
        }
    }

    // =====================================================================
    // session
    // =====================================================================

    private fun orientation(): Int = chars?.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90

    private fun pick(sizes: Array<Size>?, maxW: Int): Size? {
        if (sizes == null || sizes.isEmpty()) return null
        return sizes.filter { it.width <= maxW }.maxByOrNull { it.width * it.height }
            ?: sizes.minByOrNull { it.width * it.height }
    }

    private fun analysisFormat(map: StreamConfigurationMap?): Int {
        if (map == null) return ImageFormat.YUV_420_888
        for (f in intArrayOf(ImageFormat.YUV_420_888, ImageFormat.Y8, ImageFormat.RAW_SENSOR)) {
            if (map.getOutputSizes(f)?.isNotEmpty() == true) return f
        }
        return ImageFormat.YUV_420_888
    }

    private fun fitTextureBlocking(size: Size) {
        val sw = resources.displayMetrics.widthPixels
        val swapped = orientation() % 180 == 90
        val pw = if (swapped) size.height else size.width
        val ph = if (swapped) size.width else size.height
        val h = (sw.toLong() * ph / pw).toInt()
        if (texture.width == sw && texture.height == h) return
        val latch = CountDownLatch(1)
        runOnUiThread {
            texture.addOnLayoutChangeListener(object : View.OnLayoutChangeListener {
                override fun onLayoutChange(
                    v: View, l: Int, t: Int, r: Int, b: Int, ol: Int, ot: Int, oR: Int, ob: Int
                ) {
                    if (r - l == sw && b - t == h) {
                        v.removeOnLayoutChangeListener(this)
                        latch.countDown()
                    }
                }
            })
            texture.layoutParams = FrameLayout.LayoutParams(sw, h, Gravity.TOP)
        }
        latch.await(700, TimeUnit.MILLISECONDS)
    }

    private fun createSession(recorderSurface: Surface? = null, onReady: (() -> Unit)? = null) {
        val dev = device ?: return
        closeSession()
        val map = chars?.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
        val surfaceOk = map?.getOutputSizes(SurfaceTexture::class.java)?.isNotEmpty() == true
        yuvPath = wantYuv || !surfaceOk
        recSurface = recorderSurface
        val targets = mutableListOf<Surface>()
        var desc: String

        if (!yuvPath) {
            if (!texture.isAvailable) {
                pendingSession = true
                return
            }
            val size = pick(map!!.getOutputSizes(SurfaceTexture::class.java), 1920)!!
            fitTextureBlocking(size)
            val st = texture.surfaceTexture ?: run { pendingSession = true; return }
            st.setDefaultBufferSize(size.width, size.height)
            val s = Surface(st)
            previewSurface = s
            targets += s
            desc = "Preview ${size.width}x${size.height}"

            if (recorderSurface == null) {
                val capFmt = when {
                    wantRaw && map.getOutputSizes(ImageFormat.RAW_SENSOR)?.isNotEmpty() == true -> ImageFormat.RAW_SENSOR
                    map.getOutputSizes(ImageFormat.JPEG)?.isNotEmpty() == true -> ImageFormat.JPEG
                    else -> 0
                }
                if (capFmt != 0) {
                    val cs = map.getOutputSizes(capFmt).maxByOrNull { it.width * it.height }!!
                    val r = ImageReader.newInstance(cs.width, cs.height, capFmt, 2)
                    r.setOnImageAvailableListener({ rd -> onCaptureImage(rd) }, bg)
                    captureReader = r
                    targets += r.surface
                    desc += " | still ${if (capFmt == ImageFormat.JPEG) "JPEG" else "RAW"} ${cs.width}x${cs.height}"
                }
            }
            runOnUiThread { gray.visibility = View.GONE }
        } else {
            val fmt = analysisFormat(map)
            val size = if (map == null) Size(640, 480) else pick(map.getOutputSizes(fmt), 1280)!!
            val r = ImageReader.newInstance(size.width, size.height, fmt, 3)
            r.setOnImageAvailableListener({ rd -> onPreviewFrame(rd) }, bg)
            previewReader = r
            targets += r.surface
            bmp = null
            val fname = when (fmt) {
                ImageFormat.RAW_SENSOR -> "RAW16"
                ImageFormat.Y8 -> "Y8"
                else -> "YUV(Y plane)"
            }
            desc = "Analysis $fname ${size.width}x${size.height}"
            runOnUiThread { gray.visibility = View.VISIBLE }
        }
        recorderSurface?.let { targets += it }
        frameInfo = desc

        try {
            @Suppress("DEPRECATION")
            dev.createCaptureSession(targets, object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) {
                    if (device !== dev) {
                        s.close()
                        return
                    }
                    session = s
                    startRepeating()
                    onReady?.invoke()
                }

                override fun onConfigureFailed(s: CameraCaptureSession) {
                    toast("Stream configuration rejected for camera $camId ($desc). " +
                        "Try Analysis view, or uncheck RAW.")
                }
            }, bg)
        } catch (t: Throwable) {
            toast("Session error: ${t.message}")
        }
    }

    private fun applyControls(b: CaptureRequest.Builder) {
        b.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO)
        val afModes = chars?.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES)
        if (manual) {
            b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
            b.set(CaptureRequest.SENSOR_SENSITIVITY, iso)
            b.set(CaptureRequest.SENSOR_EXPOSURE_TIME, expNs)
            if (minFocus > 0f) {
                b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
                b.set(CaptureRequest.LENS_FOCUS_DISTANCE, focusD)
            }
        } else if (afModes != null && afModes.contains(CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)) {
            b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
        }
        if (flashOk && torchOn) b.set(CaptureRequest.FLASH_MODE, CaptureRequest.FLASH_MODE_TORCH)
    }

    private val resultCb = object : CameraCaptureSession.CaptureCallback() {
        override fun onCaptureCompleted(s: CameraCaptureSession, r: CaptureRequest, res: TotalCaptureResult) {
            lastResult = res
            val now = System.currentTimeMillis()
            if (now - lastStatusMs > 500) {
                lastStatusMs = now
                val isoV = res.get(CaptureResult.SENSOR_SENSITIVITY)
                val expV = res.get(CaptureResult.SENSOR_EXPOSURE_TIME)
                val text = "ID $camId | $frameInfo\nISO ${isoV ?: "?"} | ${if (expV != null) fmtExp(expV) else "?"}" +
                    (if (recording) " | REC" else "")
                runOnUiThread { status.text = text }
            }
        }
    }

    private fun startRepeating() {
        val s = session ?: return
        val dev = device ?: return
        try {
            val b = dev.createCaptureRequest(
                if (recording) CameraDevice.TEMPLATE_RECORD else CameraDevice.TEMPLATE_PREVIEW
            )
            previewSurface?.let { b.addTarget(it) }
            previewReader?.let { b.addTarget(it.surface) }
            recSurface?.let { b.addTarget(it) }
            applyControls(b)
            s.setRepeatingRequest(b.build(), resultCb, bg)
        } catch (t: Throwable) {
            toast("Repeating request failed: ${t.message}")
        }
    }

    private fun pushControls() {
        if (session != null) bg?.post { startRepeating() }
    }

    // =====================================================================
    // analysis view (grayscale / false colour for IR and raw-only sensors)
    // =====================================================================

    private fun onPreviewFrame(reader: ImageReader) {
        val img: Image = (try { reader.acquireLatestImage() } catch (ignored: Throwable) { null }) ?: return
        try {
            renderFrame(img)
        } finally {
            img.close()
        }
    }

    private fun renderFrame(img: Image) {
        val w = img.width
        val h = img.height
        val is16 = img.format == ImageFormat.RAW_SENSOR
        val p = img.planes[0]
        val buf = p.buffer
        val rs = p.rowStride
        val ps = p.pixelStride
        if (luma.size != w * h) luma = IntArray(w * h)

        var mn = Int.MAX_VALUE
        var mx = 0
        for (y in 0 until h) {
            var idx = y * rs
            for (x in 0 until w) {
                val v = if (is16) {
                    (buf.get(idx).toInt() and 0xFF) or ((buf.get(idx + 1).toInt() and 0xFF) shl 8)
                } else {
                    buf.get(idx).toInt() and 0xFF
                }
                luma[y * w + x] = v
                if (v < mn) mn = v
                if (v > mx) mx = v
                idx += ps
            }
        }

        val fm = filterMode
        val stretch = is16 || fm == 1 || fm == 2
        val lo = if (stretch) mn else 0
        val hi = if (stretch) max(mx, mn + 1) else 255
        val rot = orientation()
        val sideways = rot == 90 || rot == 270
        val ow = if (sideways) h else w
        val oh = if (sideways) w else h
        if (pix.size != ow * oh) pix = IntArray(ow * oh)

        for (y in 0 until h) {
            for (x in 0 until w) {
                var g = (luma[y * w + x] - lo) * 255 / (hi - lo)
                if (g < 0) g = 0 else if (g > 255) g = 255
                if (fm == 3) g = 255 - g
                val col = if (fm == 2) heat[g] else (0xFF shl 24) or (g shl 16) or (g shl 8) or g
                val dx: Int
                val dy: Int
                when (rot) {
                    90 -> { dx = h - 1 - y; dy = x }
                    180 -> { dx = w - 1 - x; dy = h - 1 - y }
                    270 -> { dx = y; dy = w - 1 - x }
                    else -> { dx = x; dy = y }
                }
                pix[dy * ow + dx] = col
            }
        }

        var b = bmp
        if (b == null || b.width != ow || b.height != oh) {
            b = Bitmap.createBitmap(ow, oh, Bitmap.Config.ARGB_8888)
            bmp = b
            runOnUiThread { gray.setImageBitmap(b) }
        }
        b!!.setPixels(pix, 0, ow, 0, 0, ow, oh)
        gray.postInvalidate()

        val now = System.currentTimeMillis()
        if (now - lastStatusMs > 500) {
            lastStatusMs = now
            val text = "ID $camId | $frameInfo\nvalue range $mn..$mx" + (if (recording) " | REC" else "")
            runOnUiThread { status.text = text }
        }
    }

    // =====================================================================
    // photo
    // =====================================================================

    private fun takePhoto() {
        if (recording) {
            toast("Stop recording first")
            return
        }
        if (yuvPath) {
            saveBitmap()
            return
        }
        val s = session ?: return
        val dev = device ?: return
        val r = captureReader
        if (r == null) {
            toast("No still format on this camera. Tick 'Analysis view' to save frames as PNG.")
            return
        }
        bg?.post {
            try {
                val b = dev.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
                b.addTarget(r.surface)
                applyControls(b)
                b.set(CaptureRequest.JPEG_ORIENTATION, orientation())
                s.capture(b.build(), object : CameraCaptureSession.CaptureCallback() {
                    override fun onCaptureCompleted(
                        sess: CameraCaptureSession, req: CaptureRequest, res: TotalCaptureResult
                    ) {
                        synchronized(rawLock) { pendingResult = res }
                        trySaveRaw()
                    }
                }, bg)
            } catch (t: Throwable) {
                toast("Capture failed: ${t.message}")
            }
        }
    }

    private fun onCaptureImage(reader: ImageReader) {
        val img: Image = (try { reader.acquireNextImage() } catch (ignored: Throwable) { null }) ?: return
        if (img.format == ImageFormat.JPEG) {
            val buf = img.planes[0].buffer
            val bytes = ByteArray(buf.remaining())
            buf.get(bytes)
            img.close()
            saveBytes(bytes, "IMG_${ts()}.jpg", "image/jpeg")
        } else {
            synchronized(rawLock) {
                pendingRaw?.close()
                pendingRaw = img
            }
            trySaveRaw()
        }
    }

    private fun trySaveRaw() {
        synchronized(rawLock) {
            val img = pendingRaw
            val res = pendingResult
            val c = chars
            if (img == null || res == null || c == null) return
            pendingRaw = null
            pendingResult = null
            val dng = DngCreator(c, res)
            try {
                val uri = insert("RAW_${ts()}.dng", "image/x-adobe-dng", false)
                    ?: throw IllegalStateException("MediaStore insert failed")
                dng.setOrientation(
                    when (orientation()) { 90 -> 6; 180 -> 3; 270 -> 8; else -> 1 }
                )
                contentResolver.openOutputStream(uri)!!.use { os -> dng.writeImage(os, img) }
                toast("Saved DNG to Pictures/IRCam")
            } catch (t: Throwable) {
                toast("DNG save failed: ${t.message}")
            } finally {
                dng.close()
                img.close()
            }
        }
    }

    private fun saveBitmap() {
        val b = bmp ?: run { toast("No frame yet"); return }
        val copy = b.copy(Bitmap.Config.ARGB_8888, false)
        Thread {
            try {
                val uri = insert("IR_${ts()}.png", "image/png", false)
                    ?: throw IllegalStateException("MediaStore insert failed")
                contentResolver.openOutputStream(uri)!!.use { copy.compress(Bitmap.CompressFormat.PNG, 100, it) }
                toast("Saved PNG to Pictures/IRCam")
            } catch (t: Throwable) {
                toast("Save failed: ${t.message}")
            }
        }.start()
    }

    private fun saveBytes(bytes: ByteArray, name: String, mime: String) {
        try {
            val uri = insert(name, mime, false) ?: throw IllegalStateException("MediaStore insert failed")
            contentResolver.openOutputStream(uri)!!.use { it.write(bytes) }
            toast("Saved to Pictures/IRCam")
        } catch (t: Throwable) {
            toast("Save failed: ${t.message}")
        }
    }

    private fun insert(name: String, mime: String, video: Boolean): Uri? {
        val v = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, if (video) "Movies/IRCam" else "Pictures/IRCam")
        }
        val coll = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        return contentResolver.insert(coll, v)
    }

    // =====================================================================
    // video
    // =====================================================================

    private fun startRecording() {
        val handler = bg ?: return
        val map = chars?.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
        val size = pick(map?.getOutputSizes(MediaRecorder::class.java), 1920)
        if (size == null) {
            toast("This camera exposes no video-encoder output. IR sensors often only give raw/YUV frames. " +
                "Use Analysis view + Photo (PNG) instead.")
            return
        }
        val uri = insert("VID_${ts()}.mp4", "video/mp4", true) ?: run { toast("Cannot create video file"); return }
        val pfd = contentResolver.openFileDescriptor(uri, "w") ?: run { toast("Cannot open video file"); return }
        val mr = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else @Suppress("DEPRECATION") MediaRecorder()
        val audio = hasAudioPerm()
        try {
            if (audio) mr.setAudioSource(MediaRecorder.AudioSource.MIC)
            mr.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            mr.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            mr.setOutputFile(pfd.fileDescriptor)
            mr.setVideoEncodingBitRate(12_000_000)
            mr.setVideoFrameRate(30)
            mr.setVideoSize(size.width, size.height)
            mr.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            if (audio) {
                mr.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                mr.setAudioEncodingBitRate(128_000)
                mr.setAudioSamplingRate(44_100)
            }
            mr.setOrientationHint(orientation())
            mr.prepare()
        } catch (t: Throwable) {
            toast("Recorder setup failed: ${t.message}")
            mr.release()
            pfd.close()
            contentResolver.delete(uri, null, null)
            return
        }
        recorder = mr
        recPfd = pfd
        handler.post {
            recording = true
            createSession(mr.surface) {
                try {
                    mr.start()
                    runOnUiThread { btnRec.text = "Stop" }
                } catch (t: Throwable) {
                    toast("Recording failed to start: ${t.message}")
                    recording = false
                }
            }
        }
    }

    private fun stopRecording() {
        bg?.post {
            try {
                session?.stopRepeating()
                session?.abortCaptures()
            } catch (ignored: Throwable) {
            }
            try { recorder?.stop() } catch (ignored: RuntimeException) {}
            recorder?.release()
            recorder = null
            recPfd?.close()
            recPfd = null
            recording = false
            recSurface = null
            runOnUiThread { btnRec.text = "Rec" }
            toast("Saved video to Movies/IRCam")
            createSession()
        }
    }

    // =====================================================================
    // controls helpers
    // =====================================================================

    private fun setupControlsFromChars() {
        val c = chars
        isoRange = c?.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
        expRange = c?.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)
        minFocus = c?.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
        flashOk = c?.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        val caps = c?.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES) ?: intArrayOf()
        val manualOk = caps.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR)
        val rawOk = caps.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_RAW)
        iso = isoRange?.lower ?: 100
        expNs = expRange?.let { min(max(10_000_000L, it.lower), it.upper) } ?: 10_000_000L
        focusD = 0f
        runOnUiThread {
            sbIso.progress = 0
            sbExp.progress = 50
            sbFocus.progress = 0
            expNs = expFromSeek(50)
            swManual.isEnabled = manualOk
            if (!manualOk) swManual.isChecked = false
            sbFocus.isEnabled = manual && minFocus > 0f
            cbTorch.isEnabled = flashOk
            if (!flashOk) cbTorch.isChecked = false
            cbRaw.isEnabled = rawOk
            if (!rawOk) cbRaw.isChecked = false
            updateLabels()
        }
    }

    private fun isoFromSeek(p: Int): Int {
        val r = isoRange ?: return 100
        return (r.lower + (r.upper - r.lower) * p / 100.0).roundToInt()
    }

    private fun expFromSeek(p: Int): Long {
        val r = expRange ?: return 10_000_000L
        val lo = r.lower.toDouble()
        val hi = min(r.upper, 1_000_000_000L).toDouble()
        return (lo * (hi / lo).pow(p / 100.0)).toLong()
    }

    private fun updateLabels() {
        tvIso.text = "ISO $iso"
        tvExp.text = "Exposure ${fmtExp(expNs)}"
        tvFocus.text = if (minFocus > 0f) "Focus %.2f D (0 = infinity)".format(focusD) else "Focus: fixed"
    }

    private fun fmtExp(ns: Long): String =
        if (ns >= 1_000_000_000L / 2) "%.1f s".format(ns / 1e9) else "1/${(1e9 / ns).roundToInt()} s"

    // =====================================================================
    // dialogs / misc
    // =====================================================================

    private fun probeAll() {
        val handler = bg ?: return
        if (entries.isEmpty()) return
        closeCamera()
        toast("Testing ${entries.size} camera IDs...")
        Thread {
            val report = CameraProbe.openTest(cm, entries, handler)
            runOnUiThread {
                showText("Open test (does the HAL let us in?)", report)
                if (resumed) openSelected()
            }
        }.start()
    }

    private fun showText(title: String, text: String) {
        val tv = TextView(this).apply {
            this.text = text
            typeface = Typeface.MONOSPACE
            textSize = 11f
            setPadding(32, 16, 32, 16)
            setTextIsSelectable(true)
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(ScrollView(this).apply { addView(tv) })
            .setPositiveButton("OK", null)
            .show()
    }

    private fun toast(s: String) {
        runOnUiThread { Toast.makeText(this, s, Toast.LENGTH_LONG).show() }
    }

    private fun ts(): String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    override fun onDestroy() {
        IrIlluminatorHelper.turnOff()
        super.onDestroy()
    }
}
