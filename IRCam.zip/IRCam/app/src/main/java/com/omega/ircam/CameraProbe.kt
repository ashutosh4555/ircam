package com.omega.ircam

import android.graphics.ImageFormat
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.media.MediaRecorder
import android.os.Handler
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Finds every camera the framework will tell us about, plus "blind" IDs that
 * are not advertised but might still open (some vendor HALs hide sensors such
 * as IR / depth / mono from cameraIdList).
 */
object CameraProbe {
    const val MAX_ID = 11

    data class Entry(val id: String, val kind: String, val label: String)

    private val formatNames = mapOf(
        ImageFormat.JPEG to "JPEG",
        ImageFormat.YUV_420_888 to "YUV_420_888",
        ImageFormat.RAW_SENSOR to "RAW_SENSOR",
        ImageFormat.RAW10 to "RAW10",
        ImageFormat.RAW12 to "RAW12",
        ImageFormat.PRIVATE to "PRIVATE",
        ImageFormat.Y8 to "Y8",
        ImageFormat.NV21 to "NV21",
        ImageFormat.YV12 to "YV12",
        ImageFormat.DEPTH16 to "DEPTH16",
        ImageFormat.DEPTH_POINT_CLOUD to "DEPTH_POINT_CLOUD",
        ImageFormat.HEIC to "HEIC",
        0x24 to "RAW_PRIVATE"
    )

    private val capNames = mapOf(
        0 to "BACKWARD_COMPATIBLE", 1 to "MANUAL_SENSOR", 2 to "MANUAL_POST_PROCESSING",
        3 to "RAW", 4 to "PRIVATE_REPROCESSING", 5 to "READ_SENSOR_SETTINGS",
        6 to "BURST_CAPTURE", 7 to "YUV_REPROCESSING", 8 to "DEPTH_OUTPUT",
        9 to "CONSTRAINED_HIGH_SPEED_VIDEO", 10 to "MOTION_TRACKING",
        11 to "LOGICAL_MULTI_CAMERA", 12 to "MONOCHROME"
    )

    private fun facing(c: CameraCharacteristics): String =
        when (c.get(CameraCharacteristics.LENS_FACING)) {
            CameraCharacteristics.LENS_FACING_FRONT -> "FRONT"
            CameraCharacteristics.LENS_FACING_BACK -> "BACK"
            CameraCharacteristics.LENS_FACING_EXTERNAL -> "EXTERNAL"
            else -> "?"
        }

    private fun irHint(c: CameraCharacteristics): String {
        val cfa = c.get(CameraCharacteristics.SENSOR_INFO_COLOR_FILTER_ARRANGEMENT)
        val caps = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES) ?: intArrayOf()
        return if (cfa == 5 || 12 in caps) " · IR/mono?" else ""
    }

    fun entries(cm: CameraManager): List<Entry> {
        val out = mutableListOf<Entry>()
        val seen = mutableSetOf<String>()

        fun add(id: String, kind: String) {
            if (!seen.add(id)) return
            val tag = try {
                val c = cm.getCameraCharacteristics(id)
                facing(c) + irHint(c)
            } catch (ignored: Throwable) {
                "unreadable"
            }
            out += Entry(id, kind, "ID $id · $kind · $tag")
        }

        for (id in cm.cameraIdList) add(id, "listed")
        for (i in 0..MAX_ID) {
            val id = i.toString()
            if (id in seen) continue
            val readable = try {
                cm.getCameraCharacteristics(id)
                true
            } catch (ignored: Throwable) {
                false
            }
            add(id, if (readable) "hidden" else "blind")
        }
        return out.sortedBy { it.id.toIntOrNull() ?: 999 }
    }

    fun describe(cm: CameraManager, id: String): String {
        val c = try {
            cm.getCameraCharacteristics(id)
        } catch (e: Throwable) {
            return "Camera ID $id\nCharacteristics not readable (${e.javaClass.simpleName}).\n" +
                "It may still open - use Probe to test."
        }
        val sb = StringBuilder("Camera ID $id\n")
        fun line(k: String, v: Any?) {
            sb.append(k).append(": ").append(v ?: "n/a").append('\n')
        }

        line("Facing", facing(c))
        line("Sensor orientation", c.get(CameraCharacteristics.SENSOR_ORIENTATION))
        line(
            "HW level", when (c.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL)) {
                0 -> "LIMITED"; 1 -> "FULL"; 2 -> "LEGACY"; 3 -> "LEVEL_3"; 4 -> "EXTERNAL"; else -> "?"
            }
        )
        val caps = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES) ?: intArrayOf()
        line("Capabilities", caps.joinToString { capNames[it] ?: it.toString() })
        line(
            "Color filter", when (c.get(CameraCharacteristics.SENSOR_INFO_COLOR_FILTER_ARRANGEMENT)) {
                0 -> "RGGB"; 1 -> "GRBG"; 2 -> "GBRG"; 3 -> "BGGR"; 4 -> "RGB (no mosaic)"
                5 -> "NIR (near-infrared)"; else -> "n/a"
            }
        )
        line("Pixel array", c.get(CameraCharacteristics.SENSOR_INFO_PIXEL_ARRAY_SIZE))
        line("Physical size mm", c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE))
        line("ISO range", c.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE))
        line("Exposure ns range", c.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE))
        line("Max frame ns", c.get(CameraCharacteristics.SENSOR_INFO_MAX_FRAME_DURATION))
        line("White level", c.get(CameraCharacteristics.SENSOR_INFO_WHITE_LEVEL))
        line("Min focus dist (D)", c.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE))
        line("Focal lengths", c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.joinToString())
        line("Apertures", c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_APERTURES)?.joinToString())
        line("AF modes", c.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES)?.joinToString())
        line("Flash unit", c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE))
        line("Physical IDs", c.physicalCameraIds.joinToString().ifEmpty { "none" })

        val map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
        if (map == null) {
            line("Stream map", null)
        } else {
            sb.append("\nOutput formats:\n")
            for (f in map.outputFormats) {
                val sizes = map.getOutputSizes(f)?.take(6)?.joinToString { "${it.width}x${it.height}" }
                sb.append("  ").append(formatNames[f] ?: "0x${f.toString(16)}")
                    .append(": ").append(sizes ?: "-").append('\n')
            }
            sb.append("Preview surface (SurfaceTexture): ")
                .append(map.getOutputSizes(SurfaceTexture::class.java)?.size ?: 0).append(" sizes\n")
            sb.append("Video (MediaRecorder): ")
                .append(map.getOutputSizes(MediaRecorder::class.java)?.size ?: 0).append(" sizes\n")
        }
        return sb.toString()
    }

    /** Tries to open every entry in turn and reports what happened. Call off the UI thread. */
    @Suppress("MissingPermission")
    fun openTest(cm: CameraManager, entries: List<Entry>, handler: Handler): String {
        val sb = StringBuilder()
        for (e in entries) {
            val latch = CountDownLatch(1)
            var result = "no response (timeout)"
            try {
                cm.openCamera(e.id, object : CameraDevice.StateCallback() {
                    override fun onOpened(d: CameraDevice) {
                        result = "OPENS"
                        d.close()
                        latch.countDown()
                    }

                    override fun onDisconnected(d: CameraDevice) {
                        result = "disconnected"
                        d.close()
                        latch.countDown()
                    }

                    override fun onError(d: CameraDevice, error: Int) {
                        result = "error code $error"
                        d.close()
                        latch.countDown()
                    }
                }, handler)
            } catch (t: Throwable) {
                result = "${t.javaClass.simpleName}: ${t.message}"
                latch.countDown()
            }
            latch.await(3, TimeUnit.SECONDS)
            sb.append(e.label).append("\n   -> ").append(result).append("\n\n")
            try {
                Thread.sleep(250)
            } catch (ignored: InterruptedException) {
            }
        }
        return sb.toString()
    }
}
